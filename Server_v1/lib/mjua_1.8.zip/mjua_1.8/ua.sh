﻿#!/bin/sh
echo :
echo :
echo : ----------------- User Agent -----------------
echo :
java -cp lib/sip.jar:lib/ua.jar org.mjsip.ua.UA $1 $2 $3 $4 $5 $6 $7 $8 $9