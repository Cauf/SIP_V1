package org.zoolu.microutil;

public interface Comparable {

	int	compareTo(Object o);
}
