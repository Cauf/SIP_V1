package org.zoolu.microutil;

import java.io.IOException;

public class FileNotFoundException extends IOException {

	public FileNotFoundException(String str) {
		super(str);
	}
}
