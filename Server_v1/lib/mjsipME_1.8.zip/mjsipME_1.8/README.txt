Building mjSIP ME - HOWTO
__________________________________________________________________
(by Luca Veltri, 31/5/2019)


For building the library and making the jar using the 'make.bat' script you have to:
1) if not already present in the JME-SDK lib folder, get the 'mmapi.jar' file;
2) modify the 'make.bat' script according to your OS, and to JDK and JME-SDK paths;
3) run make.bat

The 'make.bat' script also creates a jad file for running the org.mjsip.microua.MicroMA program. For test it you have to:
5) modify the 'run.bat' script according to your OS, and to JDK and JME-SDK paths;
6) run run.bat

